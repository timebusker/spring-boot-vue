<template>
  <div class="menus">
    <swiper :options="swiperOption">
      <swiper-slide v-for="(page, index) in pages" :key="index">
        <div class="icon" v-for="(item,index) in page" :key="index">
          <div class='icon-img'>
            <img class='icon-img-content' :src='item.imgUrl'/>
          </div>
          <p class="icon-desc">{{item.desc}}</p>
        </div>
      </swiper-slide>
      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>
  export default{
    name: 'homeMenu',
    data: function () {
      return {
        menus: [
          {imgUrl: 'https://imgs.qunarzz.com/vc/eb/d9/1b/e24bca3f1ef6ae6ebdee15e4ca.png_92.png', remark: '徒步登山'},
          {imgUrl: 'https://imgs.qunarzz.com/vc/c8/01/32/8f6e29b7b6ce0a807742c2587a.png_92.png', remark: '深度游'}],
        swiperOption: {
          pagination: '.swiper-pagination',
          loop: true,
          autoplay: false
        }
      }
    },
    computed: {
      pages: function () {
        var pages = [];
        this.menus.forEach(function (item, index) {
          var size = Math.floor(index / 8);
          if (!pages[size]) {
            pages[size] = []
          }
          pages[size].push(item);
        });
        console.log(pages);
        return pages;
      }
    }
  }
</script>

<style lang="stylus" scoped>
  @import '~styles/varibles.styl';
  @import '~styles/mixins.styl';

  .menus >>>.swiper-container
    height 0
    padding-bottom 50%
    overflow hidden
    background-color #eee
  .icons
    margin-top: .1rem
    .icon
      position: relative
      overflow: hidden
      float: left
      width: 25%
      height: 0
      padding-bottom: 25%
      .icon-img
        position: absolute
        top: 0
        left: 0
        right: 0
        bottom: .44rem
        box-sizing: border-box
        padding: .1rem
        .icon-img-content
          display: block
          margin: 0 auto
          height: 100%
      .icon-desc
        position: absolute
        left: 0
        right: 0
        bottom: 0
        height: .44rem
        line-height: .44rem
        text-align: center
        color: $darkTextColor
        ellipsis()
</style>
