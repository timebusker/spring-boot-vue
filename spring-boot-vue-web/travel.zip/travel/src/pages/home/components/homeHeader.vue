<template>
  <!--template模板中。支持定义一个标签返回值：当前只定义了一个：<div class="header">-->
  <div class="header">
    <div class="header-left">
      <span class="iconfont back-icon">&#xe65b;</span>
    </div>
    <div class="header-search">
      <span class="iconfont">&#xe60e;</span>
      <input type="text" placeholder="请输入内容搜索！"/>
    </div>
    <div class="header-right">
      城市
      <span class="iconfont arrow-list">&#xe601;</span>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'homeHeader'
  }
</script>

<!--申明使用 stylus css样式预处器，并指定样式表作用于只在当前组件有效-->
<style lang="stylus" scoped>
  // 1 rem = html (font-size)
  @import "~styles/varibles.styl"
  .header
    display: flex
    width: 100%;
    line-height: 30px;
    background $bgColor
    text-align center
    color #ffffff
    .header-left
      width: 12%
      float left
      .back-icon
        font-size 22px
        text-align center
    .header-search
      width: 78%
      text-align: left
      margin: 2px 1px
      padding-left: 4px
      background-color white
      border-radius: 3px
      color: #ccc
      input
        width 90%
    .header-right
      width: 20%
      float: right
      .arrow-list
        font-size 14px
        text-align center
</style>
