<template>
  <div class="wrapper">
    <swiper :options="swiperOption" ref="mySwiper">
      <!-- slides -->
      <swiper-slide><img src="http://source.qunarzz.com/site/images/wns/20190308_qunar_dujia_homepage_2.jpg"></swiper-slide>
      <swiper-slide><img src="http://source.qunarzz.com/site/images/wns/20190308_qunar_dujia_homepage_6.jpg"></swiper-slide>
      <swiper-slide><img src="http://source.qunarzz.com/site/images/wns/20190222_qunar_dujia_homepage_3.jpg"></swiper-slide>
      <swiper-slide><img src="http://source.qunarzz.com/site/images/wns/20190307_dujia_homepage_top_banner_5.jpg"></swiper-slide>
      <swiper-slide><img src="http://source.qunarzz.com/site/images/wns/20190304_dujia_homepage_top_banner_4.jpg"></swiper-slide>
      <!-- Optional controls -->
      <div class="swiper-pagination" slot="pagination"></div>
    </swiper>
  </div>
</template>

<script>
  export default{
    name: 'homeSwiper',
    data () {
      return {
        swiperOption: {
          // some swiper options/callbacks
          // 所有的参数同 swiper 官方 api 参数
          // 分页控制
          pagination: '.swiper-pagination',
          // 开启自动轮播，且3s切换一次
          autoplay:true,
          // 循环轮播
          loop: true
        }
      }
    },
    computed: {
      swiper () {
        return this.$refs.mySwiper.swiper
      }
    },
    mounted () {
      // current swiper instance
      // 然后你就可以使用当前上下文内的swiper对象去做你想做的事了
      console.log('this is current swiper instance object', this.swiper);
      this.swiper.slideTo(3, 1000, true)
    }
  }
</script>

<style lang="stylus" scoped>
  .wrapper >>> .swiper-pagination-bullet-active
    background: #fff
  .wrapper
    width: 100%
    height: 0
    padding-bottom: 25.6%
    overflow hidden
    background-color #eee
    img
      width 100%
</style>
