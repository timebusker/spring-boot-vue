## travel项目开发笔记

> 这是一个旅游项网站站

#### 第一天
- 初始化项目

```
# 使用vue-cli构建项目，webpack作为打包部署工具
vue init webpack travel
```

- idea中ES6代码检查设置：

```
# idea ESLint 关闭代码检查

config/index.js --> useEslint: false,
```

- viewport设置：

```
# 利用meta标签对viewport进行控制
# 移动设备默认的viewport是layout viewport，但在进行移动设备网站的开发时，需要的是ideal viewport。要得到ideal viewport，需要用到meta标签
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

# width  设置layout viewport 的宽度，为一个正整数，或字符串"width-device"
# initial-scale 设置页面的初始缩放值，为一个数字，可以带小数
# minimum-scale 允许用户的最小缩放值，为一个数字，可以带小数
# maximum-scale 允许用户的最大缩放值，为一个数字，可以带小数
# height 设置layout viewport 的高度，这个属性并不重要，很少使用
# user-scalable 是否允许用户进行缩放，值为"no"或"yes", no 代表不允许，yes代表允许
```

- 常用样式引用：

```
# reset.css: 重置浏览器的默认样式(各大厂之间各有不同)

# 移动端1像素（1px）解决方案：border.css
# 面对多端屏幕分辨率不同问题（设计师要的1px指的是物理像素，而我们写的是逻辑像素：css像素=物理像素/dpr=1/2=0.5px ）
# 原理是把原先元素的 border 去掉，然后利用 :before 或者 :after 重做 border ，设置其高为一个像素，然后设置上边框也为一个像素，最后通过 CSS3 的 transform 属性把伪元素缩放为原来的一半大小。原先的元素相对定位，新做的 border 绝对定位
```

- 常用JS类库引用

```
# FastClick:移动设备上的浏览器默认会在用户点击屏幕大约延迟300毫秒后才会触发点击事件，这是为了检查用户是否在做双击。为了能够立即响应用户的点击事件，才有了FastClick。
# npm安装
npm install fastclick --save

# Stylus是一个CSS预处理器
# CSS 预处理器是一种语言用来为 CSS 增加一些编程的的特性，无需考虑浏览器的兼容性问题，例如你可以在 CSS 中使用变量、简单的程序逻辑、函数等等在编程语言中的一些基本技巧，可以让你的 CSS 更见简洁，适应性更强，代码更直观等诸多好处。
npm install stylus --save 
npm install stylus-loader 
```

```
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// 引用fastclick
import fastClick from 'fastclick'
// 应用基础样式
import './assets/styles/reset.css'
import './assets/styles/border.css'

Vue.config.productionTip = false;
// 初始化FastClick实例并绑定到body上
fastClick.attach(document.body);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})

# 基于@符号别名路径设置 文件引用别名，简化文件引入.
# webpack.base.conf.js
resolve: {
  extensions: ['.js', '.vue', '.json'],
  alias: {
    'vue$': 'vue/dist/vue.esm.js',
    '@': resolve('src'),
    'styles': resolve('src/assets/styles'),
  }
},


# display:flex 弹性布局


# 基于stylus预处理能力，定义CSS变量全局使用
# 引用格式：（~）
@import "~styles/varibles.styl"

```

#### 第二天

```
# 首页轮播图
# 使用github开源vue-awesome-swiper实现
# 指定版本
npm install vue-awesome-swiper@3.0.7 --save

# css 给img预留占位符位置
# 在进入页面时，如果图片还没有加载进来应该给到它一个预留位置；不然如果不预留等图处加载进来就会蹭的一下把文字挤下去会不太好看；
img
  width: 100%
  height: 0
  padding-bottom: 25.6%
  overflow hidden
  
# 在stylus中：样式击穿
# stylus中我们使用scoped限定了样式表的作用域，但依然可以通过样式击穿，把样式内容传递到所有子组件中
.wrapper >>> .swiper-pagination-bullet-active
    background: #fff

# 使用vue-awesome-swiper实现菜单分页轮播滚动
# 基于计算属性对轮播分页进行控制

```

#### 第三天

```
# 使用axios发起ajax请求动态获取数据

# 编辑config/index.js配置代理转发
# 将请求转发到/static/mork下读取文件
proxyTable: {
  '/api': {
    target: 'http://localhost:8080'
	pathRewrite:{
	  '^api/':'/static/mork' 
	}
  }
}

# 将请求转发到80端口服务器上
proxyTable: {
  '/api': {
    target: 'http://localhost:80'
  }
}

```

#### 第四天

```
# 项目部署：
# 配置项目根目录名称，默认（无）
assetsPublicPath: '/',
```