<template>
  <div class="home">
    <home-header></home-header>
    <home-swiper></home-swiper>
    <home-menu></home-menu>
  </div>
</template>

<script>
  import homeHeader from './components/homeHeader'
  import homeSwiper from './components/homeSwiper'
  import homeMenu from './components/homeMenu'
  export default {
    name: 'home',
    components: {
      homeHeader,
      homeSwiper,
      homeMenu
    }
  }
</script>

<!--申明使用 stylus css样式预处器，并指定样式表作用于只在当前组件有效-->
<style lang="stylus" scoped>
  // 1 rem = html (font-size)
  .home
    height: auto

</style>
