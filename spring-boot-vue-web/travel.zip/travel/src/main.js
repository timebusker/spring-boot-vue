// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
// 引用fastclick
import fastClick from 'fastclick'
import VueAwesomeSwiper from 'vue-awesome-swiper'

// 全局引入(已经配置别名简化引用路径)
// 应用基础样式
import 'styles/reset.css'
import 'styles/border.css'
import 'styles/iconfont.css'
import 'swiper/dist/css/swiper.css'

Vue.config.productionTip = false;
// 初始化FastClick实例并绑定到body上
fastClick.attach(document.body);
Vue.use(VueAwesomeSwiper, /* { default global options } */);

new Vue({
  el: '#app',
  router,
  components: {App},
  template: '<App/>'
});
